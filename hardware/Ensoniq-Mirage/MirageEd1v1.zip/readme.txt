****************************************************************

Mirage Ed - is a freeware program that allows full access to the Ensoniq Mirage using Windows 95/98 with no restrictions. 

****************************************************************


Upon unzipping you should find the following files:-

MirageEd1v1.exe - the main program, version 1.1
MirageEd.ini - parameter settings, see below.
EnvPresets.me1 - contains envelope presets.

basicA.wav -  sample data, can delete
Bass1.wav -  sample data, can delete
ep1a.wav -  sample data, can delete
test.wav -  contains last wavesample got from Mirage - do not delete

readme.txt - this file

Mirhelp2.hlp - contains version 1.1 help file.
Mirhelp2.cnt - contents for help.
	------------------------------

How to install:

1. Create a folder and copy all the files into it.

2. Move the MirageEd.ini file into your C:/WINDOWS directory

3. Run MirageEd1v1.exe

4. Goto Setup | MIDI Ports and select your MIDI ports.

5. Hook up your Mirage via MIDI (both in and out) and boot up with MASOS V2.0


	---------------------------------

NOTES:

test.wav is the result of extracting the current wavesample from the Mirage. It can be viewed/edited as any normal WAV file.

MirageEd does not leave footmarks, 95/98 registry is not altered.

Functionality under XP is not guaranteed.


Bug reports: please feel free to make bug reports, corrections or suggestions.


Version 1.1 Feb 2008 modifications:

1. Fixed sample play when "got" from the Mirage.
2. Added sample rotate function/menu

have fun!

dave_barraclough@hotmail.com
England 2003/2008